#include <stdio.h>
#include <locale.h>
main()
{
	setlocale (LC_ALL, "");
	int x, soma=0;
	for(x=1; x<=50; x++)
	{
		printf("\n %d", x);
		soma=soma+x;
	}
	printf("\n a soma � %d", soma);
}
