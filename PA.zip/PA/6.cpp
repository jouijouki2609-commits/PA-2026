#include <stdio.h>
#include <locale.h>
main()
{
	setlocale (LC_ALL, "");
	int cont, num;
	for(cont=0;cont<=500; cont++){
	if(cont%5==0){
		printf("\n %d", cont);
		}
	}
}
