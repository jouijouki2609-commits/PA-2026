#include <stdio.h>
#include <locale.h>
main()
{
	setlocale (LC_ALL, "");
	int cont, menor, maior, num;
	for(cont=0;cont<=1000; cont++){
	if(cont%2==0){
		printf("\n %d", cont);
		}
	}
}
