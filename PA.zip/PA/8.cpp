#include <stdio.h>
#include <locale.h>
main()
{
	setlocale (LC_ALL, "");
	int cont, num, quant=0;
	for(cont=1;cont<=20; cont++){
		printf("\ndigite um numero");
		scanf("%d", &num);
	if(num%2==0){
	quant++;
		}
	}
	printf("a quantidade de pares �: %d", quant);
}
