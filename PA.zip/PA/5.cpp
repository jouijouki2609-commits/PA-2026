#include <stdio.h>
#include <locale.h>
main()
{
	setlocale (LC_ALL, "");
	int cont, num=0, mulheres=0, homens=0;
	for(cont=1;cont<=250; cont++){
		printf("digite seu sexo 1 para mulher e 2 para homem");
		scanf("%d", &num);
		if(num==1){
			mulheres++;
		}
		if(num==2){
			homens++;
		}
		}
		printf("o total de mulheres �: %d \n o total de homens �: %d", mulheres, homens);
	}

