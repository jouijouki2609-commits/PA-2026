#include <stdio.h>
#include <locale.h>
main()
{
	setlocale (LC_ALL, "");
	int cont, menor, maior, num;
	for(cont=2;cont<=35; cont++){
	if(cont==2 || cont==5|| cont==8||cont==11||cont==14||cont==17||cont==20||cont==23||cont==26||cont==29||cont==32||cont==35){
		printf("\n %d", cont);
		
	}
	}
}
