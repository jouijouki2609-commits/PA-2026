#include <stdio.h>
#include <locale.h>
main()
{
	setlocale (LC_ALL, "");
	int cont, num;
	for(cont=1;cont<=50; cont++){
		printf("digite um numero");
		scanf("%d", &num);
	if(num>=10 && num<=20){
		printf("\n %d", num);
		}
	}
}
