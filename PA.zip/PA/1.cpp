#include <stdio.h>
#include <locale.h>
main()
{
	setlocale (LC_ALL, "");
	int cont, menor, maior, num;
	for(cont=1;cont<=30; cont++){
		printf("digite um numero");
		scanf("%d", &num);
		if(cont==1)
		{
			maior=num;
			menor=num;
		}
		if(num<=menor && num<=maior && cont>1)
		{
			menor=num;
		}
		if(num>=maior && num>=menor && cont>1)
		{
			maior=num;
		}
	}
	printf("\n o maior � %d e o menor � %d", maior, menor);
}
